<?php $__env->startSection('title_postfix', 'Equipamentos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lista de Patrimônios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('flash_message')): ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div align="center" class="alert <?php echo e(session('flash_message')['class']); ?>">
                    <?php echo e(session('flash_message')['msg']); ?>

                </div>
            </div>
        </div>
    </div>

    <?php endif; ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                        <ol class="breadcrumb panel-heading">
                            <li class="active">Patrimônios</li>
                        </ol>
                        <div class="panel-body">
                        <p>
                            <a href="<?php echo e(route('patrimonies.create')); ?>" class="btn btn-success">Adicionar Patrimônio</a>
                        </p>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <th>#</th>
                                    <th>Nome</th>
                                    <th>Categoria</th>
                                    <th>Modelo</th>
                                    <th>Descrição</th>
                                    <th>Local</th>
                                    <th>Imagem</th>
                                    <th>Ação</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $patrimonies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patrimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($patrimony->id); ?></td>
                                            <td><?php echo e($patrimony->name); ?></td>
                                            <td><?php echo e($patrimony->category); ?></td>
                                            <td><?php echo e($patrimony->model); ?></td>
                                            <td><?php echo e($patrimony->description); ?></td>
                                            <td><?php echo e($patrimony->location); ?></td>
                                            <td><?php echo e($patrimony->image); ?></td>
                                            <td>
                                                <a class="btn btn-default" href="<?php echo e(route('patrimonies.edition', $patrimony->id)); ?>">Editar</a>
                                                <a class="btn btn-danger" href="javascript:(confirm('Deletar registro?') ? window.location.href = '<?php echo e(route('patrimonies.delete', $patrimony->id)); ?>' : false)">Deletar</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                                </tbody>
                            </table>
                        </div>
                        <div align="center">
                            <?php echo $patrimonies->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>