<?php $__env->startSection('title_postfix', 'Equipamentos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Patrimônio</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <ol class="breadcrumb panel-heading">
                        <li><a href="<?php echo e(route('patrimonies.index')); ?>">Patrimônios</a></li>
                        <li class="active">Editar</li>
                    </ol>
                    <div class="panel-body">
                        <form action="<?php echo e(route('patrimonies.edit', $patrimony->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="put">
                            <div class="form-group">
                                <label for="nome">Nome</label>
                                <input type="text" class="form-control" name="name" placeholder="Nome" required="" value="<?php echo e($patrimony->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="category">Categoria</label>
                                <input type="text" class="form-control" name="category" placeholder="Categoria" required="" value="<?php echo e($patrimony->category); ?>">
                            </div>
                            <div class="form-group">
                                <label for="model">Modelo</label>
                                <input type="text" class="form-control" name="model" placeholder="Modelo" required="" value="<?php echo e($patrimony->model); ?>">
                            </div>
                            <div class="form-group">
                                <label for="description">Descrição</label>
                                <input type="text" class="form-control" name="description" placeholder="Descrição" required="" value="<?php echo e($patrimony->description); ?>">
                            </div>
                            <div class="form-group">
                                <label for="local">Local</label>
                                <input type="text" class="form-control" name="location" placeholder="Nº da Sala" required="" value="<?php echo e($patrimony->location); ?>">
                            </div>
                            <div class="form-group">
                                <label for="image">Imagem</label>
                                <input type="file" class="form-control" name="image" placeholder="Imagem" value="<?php echo e($patrimony->image); ?>">
                            </div>
                            <button type="submit" class="btn btn-success">Salvar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>